public class ThreadExample {
    private static int counter = 0;

    public static void main(String[] args) {
        Thread thread1 = new Thread(new IncrementRunnable());
        Thread thread2 = new Thread(new IncrementRunnable());

        thread1.start();
        thread2.start();

        try {
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Final counter value: " + counter);
    }

    static class IncrementRunnable implements Runnable {
        public void run() {
            for (int i = 0; i < 5; i++) {
                incrementCounter();

                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        private synchronized void incrementCounter() {
            counter++;
        }
    }
}