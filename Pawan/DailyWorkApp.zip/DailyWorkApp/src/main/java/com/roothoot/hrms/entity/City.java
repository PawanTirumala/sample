package com.roothoot.hrms.entity;


import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


import lombok.Data;

@Entity
@Data
@Table(name = "cities")
public class City extends CoreMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int id;

	@OneToOne(cascade = CascadeType.DETACH)
	@JoinColumn(name = "stateid")
	private State state;

	@OneToOne(cascade = CascadeType.DETACH)
	@JoinColumn(name = "countryid")
	private Country country;

}
