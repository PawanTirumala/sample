package com.roothoot.hrms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.roothoot.hrms.entity.Country;
import com.roothoot.hrms.entity.State;

public interface StateRepository extends JpaRepository<State, Integer> {


	@Query("SELECT st FROM State st WHERE st.active IN (0, 1)")
	List<State> findAllActiveinState();

	
	
	State findByName(String name);
	State findByCode(String code);
	List<State> findByCountries(Country country);
	
}
