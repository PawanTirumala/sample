package com.roothoot.hrms.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.roothoot.hrms.entity.EntityManager;

public interface EntityManagerRepository extends JpaRepository<EntityManager, Integer> {

	@Query("SELECT em FROM EmployeeMaster em WHERE em.active = 1")
	List<EntityManager> findAllActiveUsersinEntityManager();
}
