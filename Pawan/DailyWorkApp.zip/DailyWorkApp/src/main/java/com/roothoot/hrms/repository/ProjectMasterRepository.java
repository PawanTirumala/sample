package com.roothoot.hrms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.roothoot.hrms.entity.*;

public interface ProjectMasterRepository extends JpaRepository<ProjectMaster, Integer> {


	@Query("SELECT pm FROM ProjectMaster pm WHERE pm.active = 1")
	List<ProjectMaster> findAllActiveUsersinProjectMaster();

}
