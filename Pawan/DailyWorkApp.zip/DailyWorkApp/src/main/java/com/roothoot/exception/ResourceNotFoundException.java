package com.roothoot.exception;

public class ResourceNotFoundException {

}
