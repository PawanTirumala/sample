package com.roothoot.hrms.service;

import java.time.Instant;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.roothoot.hrms.entity.DomainMaster;
import com.roothoot.hrms.repository.DomainMasterRepository;

@Service
public class DomainMasterService {

	@Autowired
	private DomainMasterRepository repository;

	public DomainMaster saveDomainMaster(DomainMaster domainmaster) {
		domainmaster.setInsertedOn(Instant.now().toString());
		return repository.save(domainmaster);
	}

	public List<DomainMaster> saveDomainMasters(List<DomainMaster> domainmasters) {
		return repository.saveAll(domainmasters);
	}

	public List<DomainMaster> getDomainMasters() {
		return repository.findAllActiveDomainMasters();
	}

	public DomainMaster getDomainMasterById(int id) {
		return repository.findById(id).orElse(null);
	}

	public String deleteDomainMaster(int id) {
		
		DomainMaster dm =  getDomainMasterById(id);
		dm.setActive(0);
		saveDomainMaster(dm);
		return "DomainMaster removed !! " + id;
	}

	public DomainMaster updateDomainMaster(DomainMaster domainmaster) {
		DomainMaster existingDomainMaster = repository.findById(domainmaster.getId()).orElse(null);
		existingDomainMaster.setId(domainmaster.getId());
		existingDomainMaster.setName(domainmaster.getName());
		existingDomainMaster.setCode(domainmaster.getCode());
		existingDomainMaster.setDescription(domainmaster.getDescription());
		existingDomainMaster.setActive(domainmaster.getActive());
		existingDomainMaster.setUpdatedBy(domainmaster.getUpdatedBy());
		existingDomainMaster.setUpdatedOn(Instant.now().toString());
//		repository.save(domainmaster);
//		repository.save(domainmaster);
		existingDomainMaster.setInsertedBy(domainmaster.getInsertedBy());
		existingDomainMaster.setSessionId(domainmaster.getSessionId());
		return repository.save(existingDomainMaster);
	}

}
