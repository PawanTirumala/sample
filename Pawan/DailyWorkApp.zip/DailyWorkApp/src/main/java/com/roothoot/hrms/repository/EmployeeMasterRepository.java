package com.roothoot.hrms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.roothoot.hrms.entity.EmployeeMaster;

public interface EmployeeMasterRepository extends JpaRepository<EmployeeMaster, Integer> {

	@Query("SELECT e FROM EmployeeMaster e WHERE e.active = 1")
	List<EmployeeMaster> findAllActiveUsersinEmployeeMaster();
}

