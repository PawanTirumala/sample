package com.roothoot.hrms.service;

import java.time.Instant;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.roothoot.hrms.entity.ProjectWiseTask;
import com.roothoot.hrms.repository.ProjectWiseTaskRepository;

@Service
public class ProjectWiseTaskService {

	@Autowired
	private ProjectWiseTaskRepository repository;

	public ProjectWiseTask saveProjectWiseTask(ProjectWiseTask projectwisetask) {
		projectwisetask.setInsertedOn(Instant.now().toString());
		return repository.save(projectwisetask);
	}

	public List<ProjectWiseTask> saveProjectWiseTasks(List<ProjectWiseTask> projectwisetasks) {
		return repository.saveAll(projectwisetasks);
	}

	public List<ProjectWiseTask> getProjectWiseTasks() {
		return repository.findAllActiveinProjectWiseTask();
	}

	public ProjectWiseTask getProjectWiseTaskById(int id) {
		return repository.findById(id).orElse(null);
	}

	public String deleteProjectWiseTask(int id) {
    repository.deleteById(id);
    return "ProjectWiseTask removed !! " + id;
}

	public ProjectWiseTask updateProjectWiseTask(ProjectWiseTask projectwisetask) {
		ProjectWiseTask existingProjectWiseTask = repository.findById(projectwisetask.getId()).orElse(null);
		existingProjectWiseTask.setId(projectwisetask.getId());

		existingProjectWiseTask.setUpdatedBy(projectwisetask.getUpdatedBy());
		existingProjectWiseTask.setUpdatedOn(Instant.now().toString());
//		repository.save(projectwisetask);
//		repository.save(projectwisetask);
		existingProjectWiseTask.setInsertedBy(projectwisetask.getInsertedBy());
		existingProjectWiseTask.setSessionId(projectwisetask.getSessionId());

		return repository.save(existingProjectWiseTask);
	}

}
