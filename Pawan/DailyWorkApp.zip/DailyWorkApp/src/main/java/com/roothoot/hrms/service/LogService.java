package com.roothoot.hrms.service;

import java.time.Instant;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.roothoot.hrms.entity.Log;
import com.roothoot.hrms.repository.LogRepository;

@Service
public class LogService {

	@Autowired
	private LogRepository repository;

	public Log saveLog(Log log) {
		log.setInsertedOn(Instant.now().toString());
		return repository.save(log);
	}

	public List<Log> saveLogs(List<Log> logs) {
		return repository.saveAll(logs);
	}

	public List<Log> getLogs() {
		return repository.findAllActiveinLog();
	}

	public Log getLogById(int id) {
		return repository.findById(id).orElse(null);
	}

	public String deleteLog(int id) {
		repository.deleteById(id);
		return "Log removed !! " + id;
	}

	public Log updateLog(Log log) {
		Log existingLog = repository.findById(log.getId()).orElse(null);
		existingLog.setId(log.getId());
		existingLog.setRecordId(log.getRecordId());
		existingLog.setUpdatedBy(log.getUpdatedBy());

		existingLog.setUpdatedOn(Instant.now().toString());
//		repository.save(log);
//		repository.save(log);
		
		existingLog.setInsertedBy(log.getInsertedBy());
		existingLog.setSessionId(log.getSessionId());
		return repository.save(existingLog);
	}

}
