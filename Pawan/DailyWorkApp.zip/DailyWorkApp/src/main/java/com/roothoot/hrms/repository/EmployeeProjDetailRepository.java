package com.roothoot.hrms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.roothoot.hrms.entity.EmployeeProjDetail;


public interface EmployeeProjDetailRepository extends JpaRepository<EmployeeProjDetail, Integer> {

	@Query("SELECT e FROM EmployeeProjDetail e WHERE e.active = 1")
	List<EmployeeProjDetail> findAllActiveEmployeeProjDetails();

}
