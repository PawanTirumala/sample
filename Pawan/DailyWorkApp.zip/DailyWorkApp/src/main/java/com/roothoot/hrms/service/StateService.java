package com.roothoot.hrms.service;

import java.time.Instant;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.roothoot.hrms.entity.Country;
import com.roothoot.hrms.entity.State;
import com.roothoot.hrms.repository.StateRepository;

@Service
public class StateService {

	
	@Autowired
	private StateRepository repository;
	
	
	public State saveState(State state) {
		 String name = state.getName();
		    String code = state.getCode();
		    
	if (name.equalsIgnoreCase(code)) {
		      throw new IllegalArgumentException("Name And Code Cannot Be Same");
		}
		    
   State exisname=repository.findByName(name);
   if(exisname!=null) {
	   throw new IllegalArgumentException("The Name Already Exists");
   }
   
   State exiscode=repository.findByCode(code);
     if(exiscode!=null) {
    	 throw new IllegalArgumentException("The Code Already Exists");
     }
		
//		validateState(state);
		state.setInsertedOn(Instant.now().toString());
		return repository.save(state);
	}

	
	public List<State> saveStates(List<State> States) {
		return repository.saveAll(States);
	}

	public List<State> getStates() {
		return repository.findAllActiveinState();
	}

	public State getStateById(int id) {
		return repository.findById(id).orElse(null);
	}

	public String deleteState(int id) {
		repository.deleteById(id);
		return "State removed !! " + id;
	}

	public State updateState(State state) {
		State existingState = repository.findById(state.getId()).orElse(null);
		if (state.getName().equalsIgnoreCase(state.getCode())) {
		      throw new IllegalArgumentException("Name And Code Cannot Be Same");
		}

		if (!existingState.getName().equals(state.getName())) {
			// Check if the updated name already exists in the database
			State duplicateNameState = repository.findByName(state.getName());
			if (duplicateNameState != null) {
				throw new IllegalArgumentException("The Name Already Exists");
			}
		}
		
		if (!existingState.getCode().equals(state.getCode())) {
            State duplicateCodeState = repository.findByCode(state.getCode());
            if (duplicateCodeState != null) {
                throw new IllegalArgumentException("The Code Already Exists");
            }
        }	
//    existingState.getCountries().setName(state.getCountries().getName());
		
//	  String countryName = state.getCountries().getName(); 
//	  existingState.setName(state.getCountries().getName());	
//	    Country updatedCountry = state.getCountries();
//	    existingCountry.setName(updatedCountry.getName());
//	    existingCountry.setCode(updatedCountry.getCode());
//	    existingCountry.setDescription(updatedCountry.getDescription());
//	    existingCountry.setActive(updatedCountry.getActive());
//	    existingCountry.setUpdatedBy(updatedCountry.getUpdatedBy());
//	    existingCountry.setUpdatedOn(Instant.now().toString());   
		existingState.setName(state.getName());
		existingState.setCode(state.getCode());
		existingState.setActive(state.getActive());
		existingState.setUpdatedBy(state.getUpdatedBy());
		existingState.setUpdatedOn(Instant.now().toString());
		existingState.setCountries(state.getCountries());
		existingState.setDescription(state.getDescription());
		return repository.save(existingState);
	}

	
	public State updateStateActive(int id) {
		  State existingState = repository.findById(id).orElse(null);
		  if (existingState != null) {
		    existingState.setActive(existingState.getActive() == 1 ? 0 : 1);
		    return repository.save(existingState);
		  } else {
		    throw new IllegalArgumentException("State not found with id: " + id);
		  }
		}

	
	
	
	
//	private void validateState(State state) {
//		String name = state.getName();
//		String code = state.getCode();
//
//		if (name.equals(code)) {
//			throw new IllegalArgumentException("Name and Code cannot be the same");
//		}
//
//		State existingName = repository.findByName(name);
//		if (existingName != null) {
//			throw new IllegalArgumentException("The Name already exists");
//		}
//
//		State existingCode = repository.findByCode(code);
//		if (existingCode != null) {
//			throw new IllegalArgumentException("The Code already exists");
//		}
//	}
}
