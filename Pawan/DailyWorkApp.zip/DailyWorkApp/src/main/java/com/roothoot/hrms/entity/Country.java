package com.roothoot.hrms.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name="Countries")
public class Country extends CoreMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int id;
	
	
//	
//	@OneToMany(cascade=CascadeType.ALL)
//	@JoinColumn(name="countryid",referencedColumnName="id")
//	@JoinColumn(name="countryid",referencedColumnName="id")
//	private List<States> states;
//	private List<Cities> cities;
	
	
}
