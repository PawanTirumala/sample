package com.roothoot.hrms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.roothoot.hrms.entity.TaskMaster;
import com.roothoot.hrms.service.TaskMasterService;
@CrossOrigin(origins = "*")
@RestController
public class TaskMasterController {

	@Autowired
	private TaskMasterService service;

	@GetMapping("/TaskMasters")
	public List<TaskMaster> findAllTaskMasters() {
		return service.getTaskMasters();
	}

	@GetMapping("/TaskMasterById/{id}")
	public TaskMaster findTaskMasterById(@PathVariable int id) {
		return service.getTaskMasterById(id);
	}

	@PostMapping("/addTaskMaster")
	public TaskMaster addTaskMaster(@RequestBody TaskMaster taskmaster) {
		return service.saveTaskMaster(taskmaster);
	}

	@PostMapping("/addTaskMasters")
	public List<TaskMaster> addTaskMasters(@RequestBody List<TaskMaster> taskmasters) {
		return service.saveTaskMasters(taskmasters);
	}

	@PutMapping("/updateTaskMaster")
	public TaskMaster updateTaskMaster(@RequestBody TaskMaster taskmaster) {
		return service.updateTaskMaster(taskmaster);
	}

	@GetMapping("/deleteTaskMaster/{id}")
	public String deleteTaskMaster(@PathVariable int id) {
		return service.deleteTaskMaster(id);
	}
}
