package com.roothoot.hrms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.roothoot.hrms.entity.State;
import com.roothoot.hrms.service.StateService;

@RestController
@CrossOrigin(origins = "*")
public class StateController {

	@Autowired
	private StateService service;

	@GetMapping("/States")
	public List<State> findAllStates() {
		return service.getStates();
	}

	@GetMapping("/StateById/{id}")
	public State findStateById(@PathVariable int id) {
		return service.getStateById(id);
	}

	@PostMapping("/addState")
	public State addState(@RequestBody State state) {
		return service.saveState(state);
	}

	@PostMapping("/addStates")
	public List<State> addStates(@RequestBody List<State> state) {
		return service.saveStates(state);
	}

	@PutMapping("/updateState")
	public State updateState(@RequestBody State state) {
		return service.updateState(state);
	}

	@GetMapping("/deleteState/{id}")
	public String deleteState(@PathVariable int id) {
		return service.deleteState(id);
	}
	
	@PutMapping("/updatestatusState/{id}")
	public State updateStateStatus(@PathVariable int id) {
	  return service.updateStateActive(id);
	}	
	
}
