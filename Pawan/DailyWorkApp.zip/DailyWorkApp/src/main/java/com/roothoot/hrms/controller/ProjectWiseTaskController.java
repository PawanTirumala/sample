package com.roothoot.hrms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.roothoot.hrms.entity.ProjectWiseTask;
import com.roothoot.hrms.service.ProjectWiseTaskService;
@CrossOrigin(origins = "*")
@RestController
public class ProjectWiseTaskController {

	@Autowired
	private ProjectWiseTaskService service;

	@GetMapping("/ProjectWiseTasks")
	public List<ProjectWiseTask> findAllProjectWiseTasks() {
		return service.getProjectWiseTasks();
	}

	@GetMapping("/ProjectWiseTaskById/{id}")
	public ProjectWiseTask findProjectWiseTaskById(@PathVariable int id) {
		return service.getProjectWiseTaskById(id);
	}

	@PostMapping("/addProjectWiseTask")
	public ProjectWiseTask addProjectWiseTask(@RequestBody ProjectWiseTask Projectwisetask) {
		return service.saveProjectWiseTask(Projectwisetask);
	}

	@PostMapping("/addProjectWiseTasks")
	public List<ProjectWiseTask> addProjectWiseTasks(@RequestBody List<ProjectWiseTask> Projectwisetasks) {
		return service.saveProjectWiseTasks(Projectwisetasks);
	}

	@PutMapping("/updateProjectWiseTask")
	public ProjectWiseTask updateProjectWiseTask(@RequestBody ProjectWiseTask Projectwisetask) {
		return service.updateProjectWiseTask(Projectwisetask);
	}

	@DeleteMapping("/deleteProjectWiseTask/{id}")
	public String deleteProjectWiseTask(@PathVariable int id) {
		return service.deleteProjectWiseTask(id);
	}
}
