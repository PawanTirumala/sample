package com.roothoot.hrms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.roothoot.hrms.entity.EntityManager;
import com.roothoot.hrms.service.EntityManagerService;
@CrossOrigin(origins = "*")
@RestController
public class EntityManagerController {

	@Autowired
	private EntityManagerService service;

	@GetMapping("/EntityManagers")
	public List<EntityManager> findAllEntityManagers() {
		return service.getEntityManagers();
	}

	@GetMapping("/EntityManagerById/{id}")
	public EntityManager findEntityManagerById(@PathVariable int id) {
		return service.getEntityManagerById(id);
	}

	@PostMapping("/addEntityManager")
	public EntityManager addEntityManager(@RequestBody EntityManager entitymanager) {
		return service.saveEntityManager(entitymanager);
	}

	@PostMapping("/addEntityManagers")
	public List<EntityManager> addEntityManagers(@RequestBody List<EntityManager> entitymanagers) {
		return service.saveEntityManagers(entitymanagers);
	}

	@PutMapping("/updateEntityManager")
	public EntityManager updateEntityManager(@RequestBody EntityManager entitymanager) {
		return service.updateEntityManager(entitymanager);
	}

	@DeleteMapping("/deleteEntity/{id}")
	public String deleteEntityManager(@PathVariable int id) {
		return service.deleteEntityManager(id);
	}
}
