package com.roothoot.hrms.service;

import java.time.Instant;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.roothoot.hrms.entity.EmployeeMaster;
import com.roothoot.hrms.repository.EmployeeMasterRepository;

@Service
public class EmployeeMasterService {

	@Autowired
	private EmployeeMasterRepository repository;

	public EmployeeMaster saveEmployeeMaster(EmployeeMaster employeemaster) {
		employeemaster.setInsertedOn(Instant.now().toString());
		return repository.save(employeemaster);
	}

	public List<EmployeeMaster> saveEmployeeMasters(List<EmployeeMaster> employeemasters) {
		return

		repository.saveAll(employeemasters);
	}

	public List<EmployeeMaster>

			getEmployeeMasters() {
		return repository.findAllActiveUsersinEmployeeMaster();
	}

	public EmployeeMaster getEmployeeMasterById(int id) {
		return repository.findById(id).orElse(null);
	}

	public List<EmployeeMaster> findAllActiveUsersinEmployeeMaster() {
		return repository.findAllActiveUsersinEmployeeMaster();
	}

//	public String deleteEmployeeMaster(int id) {
//		repository.deleteById(id);
//		return "EmployeeMaster removed !! " + id;
//	}

	public String deleteEmployeeMaster(int id) {

		EmployeeMaster em = getEmployeeMasterById(id);
		em.setActive(0);
		saveEmployeeMaster(em);
		return "EmployeeMaster removed !! " + id;
	}

	public EmployeeMaster updateEmployeeMaster(EmployeeMaster employeemaster) {
		EmployeeMaster existingEmployeeMaster = repository.findById(employeemaster.getId()).orElse(null);
		existingEmployeeMaster.setName(employeemaster.getName());
		existingEmployeeMaster.setCode(employeemaster.getCode());
		existingEmployeeMaster.setEmail(employeemaster.getEmail());
		existingEmployeeMaster.setDescription(employeemaster.getDescription());
		existingEmployeeMaster.setMobileNum(employeemaster.getMobileNum());
		existingEmployeeMaster.setAltMobileNum(employeemaster.getAltMobileNum());
		existingEmployeeMaster.setAddLine1(employeemaster.getAddLine1());
		existingEmployeeMaster.setAddLine2(employeemaster.getAddLine2());
		existingEmployeeMaster.setZipCode(employeemaster.getZipCode());
		existingEmployeeMaster.setPassword(employeemaster.getPassword());
		existingEmployeeMaster.setSaltCode(employeemaster.getSaltCode());
		existingEmployeeMaster.setEmpReportingMgrId(employeemaster.getEmpReportingMgrId());
		existingEmployeeMaster.setActive(employeemaster.getActive());
		existingEmployeeMaster.setUpdatedBy(employeemaster.getUpdatedBy());
		existingEmployeeMaster.setUpdatedOn(Instant.now().toString());
//		repository.save(employeemaster);
//		repository.save(employeemaster);
		existingEmployeeMaster.setInsertedBy(employeemaster.getInsertedBy());
		existingEmployeeMaster.setSessionId(employeemaster.getSessionId());
		return repository.save(existingEmployeeMaster);
	}

}
