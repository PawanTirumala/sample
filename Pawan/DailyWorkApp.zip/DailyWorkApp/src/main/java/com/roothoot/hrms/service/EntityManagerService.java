package com.roothoot.hrms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.roothoot.hrms.entity.EntityManager;
import com.roothoot.hrms.repository.EntityManagerRepository;

@Service
public class EntityManagerService {

	@Autowired
	private EntityManagerRepository repository;

	public EntityManager saveEntityManager(EntityManager entitymanager) {
		
		return repository.save(entitymanager);
	}

	public List<EntityManager> saveEntityManagers(List<EntityManager> entitymanagers) {
		return repository.saveAll(entitymanagers);
	}

	public List<EntityManager> getEntityManagers() {
		return repository.findAllActiveUsersinEntityManager();
	}

	public EntityManager getEntityManagerById(int id) {
		return repository.findById(id).orElse(null);
	}

	public String deleteEntityManager(int id) {
		repository.deleteById(id);
		return "EntityManager removed !! " + id;
	}

	public EntityManager updateEntityManager(EntityManager entitymanager) {
		EntityManager existingEntityManager = repository.findById(entitymanager.getId()).orElse(null);
		existingEntityManager.setId(entitymanager.getId());
		existingEntityManager.setEntityName(entitymanager.getEntityName());
		existingEntityManager.setPrefix(entitymanager.getPrefix());
		existingEntityManager.setSequence(entitymanager.getSequence());
//		existingEntityManager.setLength(entitymanager.getLength());
		return repository.save(existingEntityManager);
	}

}
