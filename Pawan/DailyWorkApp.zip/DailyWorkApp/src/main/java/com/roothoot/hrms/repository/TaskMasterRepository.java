package com.roothoot.hrms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.roothoot.hrms.entity.*;

public interface TaskMasterRepository extends JpaRepository<TaskMaster, Integer> {


	@Query("SELECT t FROM TaskMaster t WHERE t.active = 1")
	List<TaskMaster> findAllActiveinTaskMaster();

}
