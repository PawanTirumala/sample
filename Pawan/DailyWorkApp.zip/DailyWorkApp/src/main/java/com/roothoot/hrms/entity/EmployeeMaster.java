package com.roothoot.hrms.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "employee_master")
@Data
public class EmployeeMaster extends CoreMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String email;
	private String mobileNum;
	private String altMobileNum;
	private String addLine1;
	private String addLine2;
	private String zipCode;
	private String password;
	private String saltCode;
	private int empReportingMgrId;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "cityid")
	private City city;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "stateid")
	private State state;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "countryid")
	private Country country;
}
