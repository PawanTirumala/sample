package com.roothoot.hrms.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name="log")
public class Log extends CoreMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int id;
	private int recordId;
	
}
