package com.roothoot.hrms.service;

import java.time.Instant;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.roothoot.hrms.entity.EmployeeProjDetail;
import com.roothoot.hrms.repository.EmployeeProjDetailRepository;

@Service
public class EmployeeProjDetailService {

	@Autowired
	private EmployeeProjDetailRepository repository;

	public EmployeeProjDetail saveEmployeeProjDetail(EmployeeProjDetail employeeprojdetail) {
		employeeprojdetail.setInsertedOn(Instant.now().toString());
		return repository.save(employeeprojdetail);
	}

	public List<EmployeeProjDetail> saveEmployeeProjDetails(List<EmployeeProjDetail> employeeprojdetails) {
		return repository.saveAll(employeeprojdetails);
	}

	public List<EmployeeProjDetail> getEmployeeProjDetails() {
		return repository.findAllActiveEmployeeProjDetails();
	}

	public EmployeeProjDetail getEmployeeProjDetailById(int id) {
		return repository.findById(id).orElse(null);
	}

//	public String deleteEmployeeMaster(int id) {
//		repository.deleteById(id);
//		return "EmployeeMaster removed !! " + id;
//	}
	
public String deleteEmployeeProjDetail(int id) {
		
	EmployeeProjDetail epd =  getEmployeeProjDetailById(id);
		epd.setActive(0);
		saveEmployeeProjDetail(epd);
		return "EmployeeMaster removed !! " + id;
	}

	public EmployeeProjDetail updateEmployeeProjDetail(EmployeeProjDetail employeeprojdetail) {
		EmployeeProjDetail existingEmployeeProjDetail = repository.findById(employeeprojdetail.getId()).orElse(null);
		existingEmployeeProjDetail.setActive(employeeprojdetail.getActive());
		existingEmployeeProjDetail.setEmp_Proj_StartDate(employeeprojdetail.getEmp_Proj_StartDate());
		existingEmployeeProjDetail.setEmp_Proj_EndDate(employeeprojdetail.getEmp_Proj_EndDate());
		existingEmployeeProjDetail.setUpdatedBy(employeeprojdetail.getUpdatedBy());
		
		existingEmployeeProjDetail.setUpdatedOn(Instant.now().toString());
//		repository.save(employeeprojdetail);
//		repository.save(employeeprojdetail);
		existingEmployeeProjDetail.setInsertedBy(employeeprojdetail.getInsertedBy());
		existingEmployeeProjDetail.setSessionId(employeeprojdetail.getSessionId());

		return repository.save(existingEmployeeProjDetail);
	}

}

