package com.roothoot.hrms.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import lombok.Data;

@Data
@Entity
@Audited
@Table(name = "EntityManager")
public class EntityManager {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@SequenceGenerator(name = "EntityManager_sequence", sequenceName = "EntityManager_sequence", allocationSize = 1)
	private int id;
	private String entityName;
	private String prefix;
	private int sequence;
	private int length;
	
}
