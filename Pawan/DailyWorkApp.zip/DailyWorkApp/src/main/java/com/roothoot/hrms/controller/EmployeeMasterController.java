package com.roothoot.hrms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.roothoot.hrms.entity.EmployeeMaster;
import com.roothoot.hrms.service.EmployeeMasterService;
@CrossOrigin(origins = "*")
@RestController
public class EmployeeMasterController {

	@Autowired
	private EmployeeMasterService service;

	@GetMapping("/EmployeeMasters")
	public List<EmployeeMaster> findAllActiveUsersinEmployeeMaster() {
		return service.findAllActiveUsersinEmployeeMaster();
	}

	@GetMapping("/EmployeeMasterById/{id}")
	public EmployeeMaster findEmployeeMasterById(@PathVariable int id) {
		return service.getEmployeeMasterById(id);
	}

	@PostMapping("/addEmployeeMaster")
	public EmployeeMaster addEmployeeMaster(@RequestBody EmployeeMaster employeemaster) {
		return service.saveEmployeeMaster(employeemaster);
	}

	@PostMapping("/addEmployeeMasters")
	public List<EmployeeMaster> addEmployeeMasters(@RequestBody List<EmployeeMaster> employeemasters) {
		return service.saveEmployeeMasters(employeemasters);
	}

	@PutMapping("/update")
	public EmployeeMaster updateEmployeeMaster(@RequestBody EmployeeMaster employeemaster) {
		return service.updateEmployeeMaster(employeemaster);
	}

	@DeleteMapping("/delete/{id}")
	public String deleteEmployeeMaster(@PathVariable int id) {
		return service.deleteEmployeeMaster(id);
	}
}
