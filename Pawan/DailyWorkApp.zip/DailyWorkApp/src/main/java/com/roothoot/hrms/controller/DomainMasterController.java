package com.roothoot.hrms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.roothoot.hrms.entity.DomainMaster;
import com.roothoot.hrms.service.DomainMasterService;

@CrossOrigin(origins = "*")
@RestController
public class DomainMasterController {

	@Autowired
	private DomainMasterService service;

	@GetMapping("/DomainMasters")
	public List<DomainMaster> findAllDomainMasters() {
		return service.getDomainMasters();
	}

	@GetMapping("/DomainMasterById/{id}")
	public DomainMaster findDomainMasterById(@PathVariable int id) {
		return service.getDomainMasterById(id);
	}

	@PostMapping("/addDomainMaster")
	public DomainMaster addDomainMaster(@RequestBody DomainMaster domainmaster) {
		return service.saveDomainMaster(domainmaster);
	}

	@PostMapping("/addDomainMasters")
	public List<DomainMaster> addDomainMasters(@RequestBody List<DomainMaster> domainmasters) {
		return service.saveDomainMasters(domainmasters);
	}

	@PutMapping("/updateDomainMaster")
	public DomainMaster updateDomainMaster(@RequestBody DomainMaster domainmaster) {
		return service.updateDomainMaster(domainmaster);
	}

	@GetMapping("/deleteDomainMaster/{id}")
	public String deleteDomainMaster(@PathVariable int id) {
		return service.deleteDomainMaster(id);
	}
}
