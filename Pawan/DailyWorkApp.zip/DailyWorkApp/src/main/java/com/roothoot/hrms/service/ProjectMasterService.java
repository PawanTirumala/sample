package com.roothoot.hrms.service;

import java.time.Instant;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.roothoot.hrms.entity.ProjectMaster;
import com.roothoot.hrms.repository.ProjectMasterRepository;

@Service
public class ProjectMasterService {

	@Autowired
	private ProjectMasterRepository repository;

	public ProjectMaster saveProjectMaster(ProjectMaster projectmaster) {
		projectmaster.setInsertedOn(Instant.now().toString());
		return repository.save(projectmaster);
	}

	public List<ProjectMaster> saveProjectMasters(List<ProjectMaster> projectmasters) {
		return repository.saveAll(projectmasters);
	}

	public List<ProjectMaster> getProjectMasters() {
		return repository.findAllActiveUsersinProjectMaster();
	}

	public ProjectMaster getProjectMasterById(int id) {
		return repository.findById(id).orElse(null);
	}

	public String deleteProjectMaster(int id) {
		
		ProjectMaster pm =  getProjectMasterById(id);
		pm.setActive(0);
		saveProjectMaster(pm);
		return "ProjectMaster removed !! " + id;
	}

	public ProjectMaster updateProjectMaster(ProjectMaster projectmaster) {
		ProjectMaster existingProjectMaster = repository.findById(projectmaster.getId()).orElse(null);
		existingProjectMaster.setId(projectmaster.getId());
		existingProjectMaster.setName(projectmaster.getName());
		existingProjectMaster.setCode(projectmaster.getCode());
		existingProjectMaster.setDescription(projectmaster.getDescription());
		existingProjectMaster.setActive(projectmaster.getActive());
		existingProjectMaster.setUpdatedOn(Instant.now().toString());
//		repository.save(projectmaster);
//		repository.save(projectmaster);
		existingProjectMaster.setUpdatedBy(projectmaster.getUpdatedBy());
		existingProjectMaster.setInsertedBy(projectmaster.getInsertedBy());
		existingProjectMaster.setSessionId(projectmaster.getSessionId());

		return repository.save(existingProjectMaster);
	}

}

