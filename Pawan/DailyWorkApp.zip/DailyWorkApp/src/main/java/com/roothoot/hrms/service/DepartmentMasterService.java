package com.roothoot.hrms.service;

import java.time.Instant;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.roothoot.hrms.entity.DepartmentMaster;
import com.roothoot.hrms.repository.DepartmentMasterRepository;

@Service
public class DepartmentMasterService {

	@Autowired
	private DepartmentMasterRepository repository;

	public DepartmentMaster saveDepartmentMaster(DepartmentMaster departmentmaster) {
		departmentmaster.setInsertedOn(Instant.now().toString());
		return repository.save(departmentmaster);
	}

	public List<DepartmentMaster> saveDepartmentMasters(List<DepartmentMaster> departmentmasters) {
		return repository.saveAll(departmentmasters);
	}

	public List<DepartmentMaster> getDepartmentMasters() {
		return repository.findAllActiveDepartmentMasters();
	}

	public DepartmentMaster getDepartmentMasterById(int id) {
		return repository.findById(id).orElse(null);
	}

	public String deleteDepartmentMaster(int id) {

		DepartmentMaster dm = getDepartmentMasterById(id);
		dm.setActive(0);
		saveDepartmentMaster(dm);
		return "DepartmentMaster removed !! " + id;
	}

	public DepartmentMaster updateDepartmentMaster(DepartmentMaster departmentmaster) {
		DepartmentMaster existingDepartmentMaster = repository.findById(departmentmaster.getId()).orElse(null);
		existingDepartmentMaster.setId(departmentmaster.getId());
		existingDepartmentMaster.setName(departmentmaster.getName());
		existingDepartmentMaster.setCode(departmentmaster.getCode());
		existingDepartmentMaster.setDescription(departmentmaster.getDescription());
		existingDepartmentMaster.setActive(departmentmaster.getActive());
		existingDepartmentMaster.setUpdatedBy(departmentmaster.getUpdatedBy());
		existingDepartmentMaster.setUpdatedOn(Instant.now().toString());
//		repository.save(departmentmaster);
		existingDepartmentMaster.setInsertedOn(Instant.now().toString());
//		repository.save(departmentmaster);
		existingDepartmentMaster.setInsertedBy(departmentmaster.getInsertedBy());
		existingDepartmentMaster.setSessionId(departmentmaster.getSessionId());
		return repository.save(existingDepartmentMaster);
	}

}
