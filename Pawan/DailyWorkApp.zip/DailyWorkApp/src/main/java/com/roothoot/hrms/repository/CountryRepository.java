package com.roothoot.hrms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.roothoot.hrms.entity.Country;

public interface CountryRepository extends JpaRepository<Country,Integer>{


//	@Query("SELECT C FROM Country C WHERE C.active IN (0, 1)")
//	List<Country> findAllActiveCountries();
	
//	List<Country> findActiveCountrybyId();
	
	Country findByName(String name);
	Country findByCode(String code);

}
