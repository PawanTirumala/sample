package com.roothoot.hrms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.roothoot.hrms.entity.ProjectMaster;
import com.roothoot.hrms.service.ProjectMasterService;
@CrossOrigin(origins = "*")
@RestController
public class ProjectMasterController {

	@Autowired
	private ProjectMasterService service;

	@GetMapping("/ProjectMasters")
	public List<ProjectMaster> findAllProjectMasters() {
		return service.getProjectMasters();
	}

	@GetMapping("/ProjectMasterById/{id}")
	public ProjectMaster findProjectMasterById(@PathVariable int id) {
		return service.getProjectMasterById(id);
	}

	@PostMapping("/addProjectMaster")
	public ProjectMaster addProjectMaster(@RequestBody ProjectMaster projectmaster) {
		return service.saveProjectMaster(projectmaster);
	}

	@PostMapping("/addProjectMasters")
	public List<ProjectMaster> addProjectMasters(@RequestBody List<ProjectMaster> projectmasters) {
		return service.saveProjectMasters(projectmasters);
	}

	@PutMapping("/updateProjectMaster")
	public ProjectMaster updateProjectMaster(@RequestBody ProjectMaster projectmaster) {
		return service.updateProjectMaster(projectmaster);
	}

	@GetMapping("/deleteProjectMaster/{id}")
	public String deleteProjectMaster(@PathVariable int id) {
		return service.deleteProjectMaster(id);
	}
}
