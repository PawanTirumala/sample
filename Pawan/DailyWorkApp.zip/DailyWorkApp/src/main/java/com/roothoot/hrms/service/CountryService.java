
package com.roothoot.hrms.service;

import java.time.Instant;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.roothoot.hrms.entity.Country;
import com.roothoot.hrms.entity.State;
import com.roothoot.hrms.repository.CountryRepository;
import com.roothoot.hrms.repository.StateRepository;

@Service
public class CountryService {

	@Autowired
	private CountryRepository repository;
	@Autowired
	private StateRepository staterepository;

	public Country saveCountry(Country country) {
		validate(country);
		 
		 Country exisname=repository.findByName(country.getName());
				if(exisname!=null) {
					   throw new IllegalArgumentException("Country Name Already Exists");
				}
				
				Country exiscode=repository.findByCode(country.getCode());
				if(exiscode!=null) {
			    	 throw new IllegalArgumentException("Country Code Already Exists");
              	}
				
				country.setInsertedOn(Instant.now().toString());
		return repository.save(country);
	}

	private void validate(Country country) {
		String name=country.getName();
		String code=country.getCode();
		if(name.equalsIgnoreCase(code)) {
		   throw new IllegalArgumentException("Name And Code Cannot Be Same");
		}
		
	}

	
	public List<Country> saveCountries(List<Country> Countries) {
		return repository.saveAll(Countries);
	}

	public List<Country> getCountries() {
		return repository.findAll();
	}

	public Country getCountryById(int id) {
		return repository.findById(id).orElse(null);
	}


	  public String deleteCountry(int id) {	  
		  Country country = repository.findById(id).orElse(null);
	        if (country != null) {
	            // Delete associated states
	        	 List<State> associatedStates = staterepository.findByCountries(country);
	             for (State state : associatedStates) {
	                 staterepository.delete(state);
	             }
	             repository.delete(country);
	            return "Country removed: " + id;
	        } else {
	            throw new IllegalArgumentException("Country not found");
	        
	}

	}
	  
	  public Country Active(int id) {
		    Country existingCountry = repository.findById(id).orElse(null);
		    if (existingCountry != null) {
		      existingCountry.setActive(existingCountry.getActive() == 1 ? 0 : 1);
		      return repository.save(existingCountry);
		    } else {
		      throw new IllegalArgumentException("Country Not Found :" + id);
		    }
		  }
	  

	public Country updateCountry(Country country) {
		validate(country);
    Country byname=repository.findByName(country.getName());
   if(byname!=null && byname.getId()!=country.getId()) {
	 throw new IllegalArgumentException("Country Name Already Exists");
      }
       Country byCod=repository.findByCode(country.getCode());

    if(byCod!=null && byCod.getId()!=country.getId()) {
	 throw new IllegalArgumentException("Country Code Already Exists");
     }	
		
		Country existingCountry = repository.findById(country.getId()).orElse(null);	
//		existingCountry.setId(country.getId());
		existingCountry.setName(country.getName());
		existingCountry.setCode(country.getCode());
		existingCountry.setActive(country.getActive());
		existingCountry.setDescription(country.getDescription());
		existingCountry.setUpdatedOn(Instant.now().toString());
//		repository.save(country);
//		repository.save(country);
		existingCountry.setUpdatedBy(country.getUpdatedBy());
		existingCountry.setInsertedBy(country.getInsertedBy());
		existingCountry.setSessionId(country.getSessionId());
		return repository.save(existingCountry);
	}
	
	public Country updateStateActive(int id) {
		  Country existingCountry = repository.findById(id).orElse(null);
		  if (existingCountry != null) {
			  existingCountry.setActive(existingCountry.getActive() == 1 ? 0 : 1);
		    return repository.save(existingCountry);
		  } else {
		    throw new IllegalArgumentException("State not found with id: " + id);
		  }
		}

	
}
