package com.roothoot.hrms.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "employeeprojectdetails")
@Data
public class EmployeeProjDetail extends CoreMaster{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String Emp_Proj_StartDate;
	private String Emp_Proj_EndDate;
	
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="Emp_DeptID")
	private DepartmentMaster departmentmaster;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="Emp_ProjID")
	private ProjectMaster projectmaster;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="Emp_WorkDomainID")
	private DomainMaster domainmaster;

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="EmpID")
	private EmployeeMaster employeemaster;

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="ProjMgrID")
	private EmployeeMaster employeemasters;
	
	
}
