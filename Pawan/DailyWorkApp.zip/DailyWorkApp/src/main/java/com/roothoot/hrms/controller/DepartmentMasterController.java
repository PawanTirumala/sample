package com.roothoot.hrms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.roothoot.hrms.entity.DepartmentMaster;
import com.roothoot.hrms.service.DepartmentMasterService;
@CrossOrigin(origins = "*")
@RestController
public class DepartmentMasterController {

	@Autowired
	private DepartmentMasterService service;

	@GetMapping("/DepartmentMasters")
	public List<DepartmentMaster> findAllDepartmentMasters() {
		return service.getDepartmentMasters();
	}

	@GetMapping("/DepartmentMasterById/{id}")
	public DepartmentMaster findDepartmentMasterById(@PathVariable int id) {
		return service.getDepartmentMasterById(id);
	}

	@PostMapping("/addDepartmentMaster")
	public DepartmentMaster addDepartmentMaster(@RequestBody DepartmentMaster departmentmaster) {
		return service.saveDepartmentMaster(departmentmaster);
	}

	@PostMapping("/addDepartmentMasters")
	public List<DepartmentMaster> addDepartmentMasters(@RequestBody List<DepartmentMaster> departmentmaster) {
		return service.saveDepartmentMasters(departmentmaster);
	}

	@PutMapping("/updateDepartmentMaster")
	public DepartmentMaster updateDepartmentMaster(@RequestBody DepartmentMaster departmentmaster) {
		return service.updateDepartmentMaster(departmentmaster);
	}

	@GetMapping("/deleteDepartmentMaster/{id}")
	public String deleteDepartmentMaster(@PathVariable int id) {
		return service.deleteDepartmentMaster(id);
	}
}
