
package com.roothoot.hrms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.roothoot.hrms.entity.Country;
import com.roothoot.hrms.entity.State;
import com.roothoot.hrms.service.CountryService;
@CrossOrigin(origins = "*")
@RestController
public class CountryController {

	@Autowired
	private CountryService service;

	@GetMapping("/Countries")
	public List<Country> findAllCountries() {
		return service.getCountries();
	}

	@GetMapping("/CountryById/{id}")
	public Country findCountryById(@PathVariable int id) {
		return service.getCountryById(id);
	}

	@PostMapping("/addCountry")
	public Country addCountry(@RequestBody Country country) {
		return service.saveCountry(country);
	}

	@PostMapping("/addCountries")
	public List<Country> addCountries(@RequestBody List<Country> country) {
		return service.saveCountries(country);
	}

	@PutMapping("/updateCountry")
	public Country updateCountry(@RequestBody Country country) {
		return service.updateCountry(country);
	}
	
	
	@GetMapping("/deleteCountry/{id}")
	public String deleteCountry(@PathVariable int id) {
		return service.deleteCountry(id);
	}

	
	@PutMapping("/updatestatusCountry/{id}")
	public Country updateStateStatus(@PathVariable int id) {
	  return service.updateStateActive(id);
	}	
}
