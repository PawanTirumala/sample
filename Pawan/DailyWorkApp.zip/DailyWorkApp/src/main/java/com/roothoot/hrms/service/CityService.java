package com.roothoot.hrms.service;

import java.time.Instant;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.roothoot.hrms.entity.City;
import com.roothoot.hrms.entity.State;
import com.roothoot.hrms.repository.CityRepository;

@Service
public class CityService {
    @Autowired
	private CityRepository repository;

	public City saveCity(City city) {
		 String name = city.getName();
		    String code = city.getCode();    
	 if (name.equalsIgnoreCase(code)) {
		      throw new IllegalArgumentException("Name And Code Cannot Be Same");
		}
		    
     City exisname=repository.findByName(name);
     if(exisname!=null) {
	   throw new IllegalArgumentException("The Name Already Exists");
       }

     City exiscode=repository.findByCode(code);
     if(exiscode!=null) {
 	 throw new IllegalArgumentException("The Code Already Exists");
      }
    city.setInsertedOn(Instant.now().toString());
		return repository.save(city);
	}

	
	
	public List<City> saveCities(List<City> Cities) {
		return repository.saveAll(Cities);
	}

	
	public List<City> findAllActiveCities() {
		return repository.findAllActiveCities();
	}

	
	public City getCityById(int id) {
		return repository.findById(id).orElse(null);
	}

	
	public String deleteCity(int id) {
//		City ct = getCityById(id);
//		ct.setActive(0);
//		saveCity(ct);
		repository.deleteById(id);
		return "City removed !! " + id;
	}

	public City updateCity(City city) {
		City existingCity = repository.findById(city.getId()).orElse(null);
		
		if (city.getName().equalsIgnoreCase(city.getCode())) {
		      throw new IllegalArgumentException("Name And Code Cannot Be Same");
		}

		if (!existingCity.getName().equals(city.getName())) {
			// Check if the updated name already exists in the database
			City duplicateNameState = repository.findByName(city.getName());
			if (duplicateNameState != null) {
				throw new IllegalArgumentException("The Name Already Exists");
			}
		}
		
		if (!existingCity.getCode().equals(city.getCode())) {
          City duplicateCodeState = repository.findByCode(city.getCode());
          if (duplicateCodeState != null) {
              throw new IllegalArgumentException("The Code Already Exists");
          }
      }

//		existingCity.setId(city.getId());
		existingCity.setName(city.getName());
		existingCity.setCode(city.getCode());
		existingCity.setActive(city.getActive());
		existingCity.setDescription(city.getDescription());
		existingCity.setCountry(city.getCountry());
		existingCity.setUpdatedBy(city.getUpdatedBy());
		existingCity.setUpdatedOn(Instant.now().toString());
		existingCity.setState(city.getState());
		
//		repository.save(city);
//		repository.save(city);
//		existingCity.setInsertedBy(city.getInsertedBy());
//		existingCity.setSessionId(city.getSessionId());
		return repository.save(existingCity);
	   }
	
	
	public City updateCityActive(int id) {
		  City existingCity = repository.findById(id).orElse(null);
		  if (existingCity != null) {
			  existingCity.setActive(existingCity.getActive() == 1 ? 0 : 1);
		    return repository.save(existingCity);
		  } else {
		    throw new IllegalArgumentException("State not found with id: " + id);
		  }
		}

}
