package com.roothoot.hrms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.roothoot.hrms.entity.*;

public interface DomainMasterRepository extends JpaRepository<DomainMaster, Integer> {


	@Query("SELECT do FROM DomainMaster do WHERE do.active = 1")
	List<DomainMaster> findAllActiveDomainMasters();
}
