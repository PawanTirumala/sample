package com.roothoot.hrms.service;

import java.time.Instant;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.roothoot.hrms.entity.TaskMaster;
import com.roothoot.hrms.repository.TaskMasterRepository;

@Service
public class TaskMasterService {

	@Autowired
	private TaskMasterRepository repository;

	public TaskMaster saveTaskMaster(TaskMaster taskmaster) {
		taskmaster.setInsertedOn(Instant.now().toString());
		return repository.save(taskmaster);
	}

	public List<TaskMaster> saveTaskMasters(List<TaskMaster> taskmasters) {
		return repository.saveAll(taskmasters);
	}

	public List<TaskMaster> getTaskMasters() {
		return repository.findAllActiveinTaskMaster();
	}

	public TaskMaster getTaskMasterById(int id) {
		return repository.findById(id).orElse(null);
	}

	public String deleteTaskMaster(int id) {

		TaskMaster tm = getTaskMasterById(id);
		tm.setActive(0);
		saveTaskMaster(tm);
		return "TaskMaster removed !! " + id;
	}

	public TaskMaster updateTaskMaster(TaskMaster taskmaster) {
		TaskMaster existingTaskMaster = repository.findById(taskmaster.getId()).orElse(null);
		existingTaskMaster.setId(taskmaster.getId());
		existingTaskMaster.setName(taskmaster.getName());
		existingTaskMaster.setCode(taskmaster.getCode());
		existingTaskMaster.setDescription(taskmaster.getDescription());
		existingTaskMaster.setActive(taskmaster.getActive());
		existingTaskMaster.setUpdatedBy(taskmaster.getUpdatedBy());
		existingTaskMaster.setUpdatedOn(Instant.now().toString());
//		repository.save(taskmaster);
//		existingTaskMaster.setInsertedOn(Instant.now().toString());
//		repository.save(taskmaster);
		existingTaskMaster.setInsertedBy(taskmaster.getInsertedBy());

		return repository.save(existingTaskMaster);
	}

}
