package com.roothoot.hrms.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "projects_master")
public class ProjectMaster extends CoreMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
}
