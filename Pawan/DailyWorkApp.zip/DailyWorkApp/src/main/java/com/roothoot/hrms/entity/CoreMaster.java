package com.roothoot.hrms.entity;

import javax.persistence.MappedSuperclass;

import lombok.Data;

@Data
@MappedSuperclass
public class CoreMaster {
	
	private String name;
	private String code;
	private String description;
	private int active;
	private String updatedBy;
	private String updatedOn;
	private String insertedOn;
	private String insertedBy;
	private int sessionId;
	
}
