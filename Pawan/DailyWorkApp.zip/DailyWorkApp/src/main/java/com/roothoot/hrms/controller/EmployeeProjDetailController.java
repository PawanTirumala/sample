package com.roothoot.hrms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.roothoot.hrms.entity.EmployeeProjDetail;
import com.roothoot.hrms.service.EmployeeProjDetailService;
@CrossOrigin(origins = "*")
@RestController
public class EmployeeProjDetailController {

	@Autowired
	private EmployeeProjDetailService service;

	@GetMapping("/EmployeeProjDetails")
	public List<EmployeeProjDetail> findAllEmployeeProjDetails() {
		return service.getEmployeeProjDetails();
	}

	@GetMapping("/EmployeeProjDetailById/{id}")
	public EmployeeProjDetail findEmployeeProjDetailById(@PathVariable int id) {
		return service.getEmployeeProjDetailById(id);
	}

	@PostMapping("/addEmployeeProjDetail")
	public EmployeeProjDetail addEmployeeProjDetail(@RequestBody EmployeeProjDetail employeeprojdetail) {
		return service.saveEmployeeProjDetail(employeeprojdetail);
	}

	@PostMapping("/addEmployeeProjDetails")
	public List<EmployeeProjDetail> addEmployeeProjDetails(@RequestBody List<EmployeeProjDetail> employeeprojdetails) {
		return service.saveEmployeeProjDetails(employeeprojdetails);
	}

	@PutMapping("/updateEmployeeProjDetails")
	public EmployeeProjDetail updateEmployeeProjDetail(@RequestBody EmployeeProjDetail employeeprojdetail) {
		return service.updateEmployeeProjDetail(employeeprojdetail);
	}

	@DeleteMapping("/deleteEmployeeProjDetail/{id}")
	public String deleteEmployeeProjDetail(@PathVariable int id) {
		return service.deleteEmployeeProjDetail(id);
	}
}
