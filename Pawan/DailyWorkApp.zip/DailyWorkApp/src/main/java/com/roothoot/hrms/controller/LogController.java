package com.roothoot.hrms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.roothoot.hrms.entity.Log;
import com.roothoot.hrms.service.LogService;
@CrossOrigin(origins = "*")
@RestController
public class LogController {

	@Autowired
	private LogService service;

	@GetMapping("/Logs")
	public List<Log> findAllLogs() {
		return service.getLogs();
	}

	@GetMapping("/LogById/{id}")
	public Log findLogById(@PathVariable int id) {
		return service.getLogById(id);
	}

	@PostMapping("/addLog")
	public Log addLog(@RequestBody Log log) {
		return service.saveLog(log);
	}

	@PostMapping("/addLogs")
	public List<Log> addLogs(@RequestBody List<Log> log) {
		return service.saveLogs(log);
	}

	@PutMapping("/updateLog")
	public Log updateLog(@RequestBody Log log) {
		return service.updateLog(log);
	}

	@GetMapping("/deleteLog/{id}")
	public String deleteLog(@PathVariable int id) {
		return service.deleteLog(id);
	}
}
