package com.kushaal.App;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DailyWorkAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
